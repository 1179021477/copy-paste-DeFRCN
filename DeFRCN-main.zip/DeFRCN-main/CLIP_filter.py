from PIL import Image
from transformers import CLIPProcessor, CLIPModel
import os
import json
import torch
import shutil
import numpy as np

img_path = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_200_newrect_cutout_remove/"
img_list = os.listdir(img_path)
file_save = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_20_newrect_cutout/"

save_feature = open("./image_feature.txt","w")

if not os.path.exists(file_save):
   os.makedirs(file_save)

device = "cuda" if torch.cuda.is_available() else "cpu"
token = []
class_name = ["bird","bus","cow","motorbike","sofa", "aeroplane", "bicycle", "boat", "bottle", "car","cat", "chair", "diningtable", "dog", "horse","person", "pottedplant", "sheep", "train", "tvmonitor"]


def cos_sim(x1,x2):
    a = np.dot(x1,x2)
    b1 = np.linalg.norm(x1)
    b2 = np.linalg.norm(x2)
    return a/(b1*b2)

dict_num = {}
for k in range(len(class_name)):
     dict_num[class_name[k]] = 0

for k in range(len(class_name)):
    token.append("a "+class_name[k]) 

clip_model = "./CLIP-main/clip-vit-base-patch32/"
Clip_model = CLIPModel.from_pretrained(clip_model)
Processor = CLIPProcessor.from_pretrained(clip_model)
info = {}
feature = {}
index = 0
count = 0

#CLIP scores
for img in img_list: 
    #if index > 10:
    #    break
    index += 1
    for i in range(len(class_name[:5])):
         if class_name[i] in img:
             cls_id = i

    Img = Image.open(img_path+img)
    
    inputs = Processor(text=token, images=Img, return_tensors="pt", padding=True)
    outputs = Clip_model(**inputs)
    #print(outputs)
    image_feature = outputs.image_embeds.detach().numpy().tolist() #(1,512) #last_hidden_state[0].detach().numpy()
    #print(image_feature.shape)
    logits_per_image = outputs.logits_per_image # this is the image-text similarity score
    probs = logits_per_image.softmax(dim=1) # we can take the softmax to get the label probabilities
    #print(image_feature,type(probs))
 
    feature[img] = [image_feature, probs[0].detach().numpy().tolist()]
    if probs[0][cls_id] >= 0.2:
         count += 1
         info[img] = float(probs[0][cls_id])
    print(count,index)

save_feature.write(json.dumps(feature))
         
print(count)
new_sort_info = {}
new_sort_info2 = {}
new_sort_info3 = {}

sort_info_clip_only = sorted(info.items(), key=lambda x: x[1], reverse=True)


#Using novel instance feature
import os
import numpy as np
novel_file = "VOC_novel_instances/split1_1shot/"

file_list = os.listdir(novel_file)

n_fea_lists = {"0":[],"1":[],"2":[],"3":[],"4":[]}


#novel instance fea
for n in file_list:
     img = Image.open(novel_file+n)
     inputs = Processor(text=token,images=img,return_tensors="pt",padding=True)
     outputs = Clip_model(**inputs)
     #print(outputs.image_embeds)
     n_fea = outputs.image_embeds.detach().numpy().tolist()
     for i in range(len(class_name[:-5])):
         if class_name[i] in n:
             n_fea_lists[str(i)].append(n_fea)

#mean novel fea
for i in range(5):
    if len(n_fea_lists[str(i)]) > 1:
         #print(n_fea_lists[str(i)])
         tmp = np.array(n_fea_lists[str(i)][0])
         for j in range(1,len(n_fea_lists[str(i)])):
             tmp += np.array(n_fea_lists[str(i)][j])
         n_fea_lists[str(i)] = np.array(tmp)/len(n_fea_lists[str(i)])
         #print(np.array(n_fea_lists[str(i)]).shape)#(1,512)
         
mean_clip_fea = {}
for i in range(len(class_name[:5])):
    temp = 0
    count = 0
    for key in sort_info_clip_only:
         if class_name[i] in key[0]:
            temp += np.array(feature[key[0]][0])
            count += 1
    #f_key = key[0].split("_")[0]   
    print(class_name[i])    
    mean_clip_fea[class_name[i]] = temp/count
    
            
#cal diff using L1 or cos
dif_info = {}
for i in range(len(class_name[:5])):
    for key in sort_info_clip_only:
        #print(key)
        if class_name[i] in key[0]:
           #dif_info[key[0]] = np.absolute(np.sum(np.array(n_fea_lists[str(i)]) - np.array(feature[key[0]][0])))
           x1 = np.array(n_fea_lists[str(i)]).squeeze(0)# novel samples

           x0 = mean_clip_fea[class_name[i]]#clip fea
           x1 = 0.5*x1 +0.5*x0
           #x1 = x0

           #print(x1.shape) 
           x2 = np.array(feature[key[0]][0]).T
           sim = cos_sim(x1,x2)
           dif_info[key[0]] = sim

sort_info = sorted(dif_info.items(),key=lambda x: x[1],reverse=True)
print("diff:",sort_info)

#main
diff = True
only= False
two_stage = False #True
Random = False
import random

exist_list = []

if diff:
    for i in class_name[:5]:
       count = 0
       for key in sort_info:
           #key:tuple("*.png",0.99)
           # max 
           if i in key[0]:
           # same gap
           #if i in key[0] and count % 10 ==0:
                if dict_num[i] >= 20:
                    continue
                dict_num[i] += 1
                new_sort_info[key[0]] = key[1] 
                print("diff:",key[0])    
                shutil.copy(img_path+key[0],file_save+key[0])
           if i in key[0]:
                count += 1 
elif Random:
    for i in class_name[:5]:
        while True:
           len_info = len(sort_info)
           index = random.randint(0,len_info-1)
           if i in sort_info[index][0] and index not in exist_list:
               exist_list.append(index)
               if dict_num[i] >= 20:
                  break
               dict_num[i] += 1
               #len_info = len(sort_info)
               #index = random.randint(0,len_info-1)
               print("random:",sort_info[index][0])
               shutil.copy(img_path+sort_info[index][0],file_save+sort_info[index][0])

elif only:# Only use CLIP fea or probs
    for i in class_name[:5]:
       count = 0
       for key in sort_info_clip_only:
           #key:tuple("*.png",0.99)
           # max 
           #if i in key[0]:
           # same gap
           if i in key[0] and count % 10 ==0:
                if dict_num[i] >= 20:
                    continue
                dict_num[i] += 1
                new_sort_info[key[0]] = key[1] 
                print("only:",key[0])    
                shutil.copy(img_path+key[0],file_save+key[0])
           if i in key[0]:
                count += 1 
else:
  if two_stage:
     
     for i in class_name[:5]:
       count = 0
       for key in sort_info_clip_only:
           #key:tuple("*.png",0.99)
           #print(key)
           # max 
           #if i in key[0]:
           # same gap
           if i in key[0] and count % 5 ==0:
                #if dict_num[i] >= 20:
                #    continue
                #dict_num[i] += 1
                new_sort_info[key[0]] = key[1] 
                 
                #shutil.copy(img_path+key[0],file_save+key[0])
           if i in key[0]:
                count += 1     
     #print(len(new_sort_info))
     for i in class_name[:5]:
       count = 0
       for key in new_sort_info:
           #key:tuple("*.png")
           #print(len(new_sort_info),i,key,count)
           # max 
           #if i in key[0]:
           # same gap
           if i in key and count % 2 ==0:
                #print(dict_num)
                if dict_num[i] >= 20:
                    continue
                dict_num[i] += 1
                new_sort_info2[key] = new_sort_info[key] 
                print("twp stage:",key)
                shutil.copy(img_path+key,file_save+key)
           if i in key:
                count += 1 
  else:#0.5*score1+0.5*score2
    for key in dif_info:# diff info
        #print(key,type(sort_info),type(sort_info_clip_only),type(new_sort_info3))#list list dict
        new_sort_info3[key] = 0.5 * info[key] + 0.5 * dif_info[key]    
    new_sort_info3 = sorted(new_sort_info3.items(),key=lambda x: x[1],reverse=True)    
     
    for i in class_name[:5]:
       count = 0
       for key in new_sort_info3:
           #key:tuple("*.png",0.99)
           #print(key)
           # max 
           if i in key[0]:
           # same gap
           #if i in key[0] and count % 10 ==0:
                if dict_num[i] >= 20:
                    continue
                dict_num[i] += 1
                #new_sort_info[key[0]] = key[1] 
                 
                shutil.copy(img_path+key[0],file_save+key[0])
           if i in key[0]:
                count += 1      
     

#print(len(new_sort_info2))
#print(new_sort_info2)



