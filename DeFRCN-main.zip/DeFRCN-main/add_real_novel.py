#coding : utf-8
import os
import cv2
import abc
import xml.dom.minidom as xml
import math
import matplotlib.pyplot as plt
from PIL import Image

from save_xml import save_xml 
import random
import numpy as np
import torch
import torchvision.transforms.functional as TF
import torchvision.transforms as transforms
import copy

#import aug_lib


#from autoaugment import ImageNetPolicy
#from autoaugment import CIFAR10Policy
#from autoaugment import SVHNPolicy

'''
read voc xml
'''
 

 
class XmlReader(object):
    __metaclass__ = abc.ABCMeta
    def __init__(self):
        pass
    def read_content(self,filename):
        content = None
        if (False == os.path.exists(filename)):
            return content
        filehandle = None
        try:
            filehandle = open(filename,'rb')
        except FileNotFoundError as e:
            print(e.strerror)
        try:
            content = filehandle.read()
        except IOError as e:
            print(e.strerror)
        if (None != filehandle):
            filehandle.close()
        if(None != content):
            return content.decode("utf-8","ignore")
        return content
 
    @abc.abstractmethod
    def load(self,filename):
        pass
 
class XmlTester(XmlReader):
    def __init__(self):
        XmlReader.__init__(self)
    def load(self, filename):
        filecontent = XmlReader.read_content(self,filename)
        if None != filecontent:
            dom = xml.parseString(filecontent)
            root = dom.getElementsByTagName('annotation')[0]
            #im_size = root.getElementsByTagName('size')[0]
 
            #im_w = int((im_size.getElementsByTagName('width')[0]).childNodes[0].data)
            #im_h = int((im_size.getElementsByTagName("height")[0]).childNodes[0].data)
            #im_shape=[im_w,im_h]
            #print(dom.getElementsByTagName('object'))
            len_objs = len(dom.getElementsByTagName('object'))
            #print("len:",len_objs)
            labels = []
            diffs = []
            bboxs = []
            for i in range(len_objs):
                obj = dom.getElementsByTagName('object')[i]
                box = obj.getElementsByTagName('bndbox')[0]
                #print(obj)
                label = str((obj.getElementsByTagName("name")[0]).childNodes[0].data)
                diff = int((obj.getElementsByTagName("difficult")[0]).childNodes[0].data)
                labels.append(label)
                diffs.append(diff)

                b_xmin=int((box.getElementsByTagName("xmin")[0]).childNodes[0].data)
                b_ymin=int((box.getElementsByTagName("ymin")[0]).childNodes[0].data)
                b_xmax=int((box.getElementsByTagName("xmax")[0]).childNodes[0].data)
                b_ymax=int((box.getElementsByTagName("ymax")[0]).childNodes[0].data)
 
                bbox=[b_xmin,b_ymin,b_xmax,b_ymax]
                bboxs.append(bbox)
  
            return labels, diffs, bboxs
 

 
 
if __name__ == "__main__":
    class_name = ['bird', 'bus', 'cow', 'motorbike', 'sofa'] #1
    #class_name = ['aeroplane', 'bottle', 'cow', 'horse', 'sofa'] #2
    #class_name = ['boat', 'cat', 'motorbike', 'sheep', 'sofa'] #3

    shot_num = 2
    data_root = "datasets/"
    anno_path = "datasets/VOC2007/Annotations/"
    shot = '1shot'
    list_file = "datasets/vocsplit/seed0/"
    base_img_list = "datasets/VOC2007/ImageSets/Main/trainval.txt"
    
    files = os.listdir(list_file)
    reader = XmlTester() 
    
    f_base = open(base_img_list,"r")
    lines_base = f_base.readlines()
     
    dict_num = {}
    for c in class_name:
        dict_num[c] = 0
    print(dict_num)

    # reduce chongfu base
    count = 0
    for line_base in lines_base:
         print("count:",count)
         count += 1
         base_img_name = line_base.rstrip()
         base_xml_path = anno_path + base_img_name+".xml"                  
         print(base_xml_path)
         labels_all, diffs_all, bboxes_all = reader.load(base_xml_path)

         flag = False
         for k in range(len(labels_all)):
             if labels_all[k] in class_name and diffs_all[k] == 0:
                 flag = True
         if flag:
             for k in range(len(labels_all)):
                     txt_file = list_file + "box_"+shot+"_"+labels_all[k]+"_train.txt"   
                     if labels_all[k] in class_name and diffs_all[k] == 0:
                         if dict_num[labels_all[k]] >= shot_num:
                             break
                         dict_num[labels_all[k]]+=1
                         print(txt_file)
                         f_novel_save = open(txt_file,'a')
                         f_novel_save.write('datasets/VOC2007/JPEGImages/'+base_img_name+'.jpg'+'\n')
                         break

    anno_path = "datasets/VOC2012/Annotations/"
    base_img_list = "datasets/VOC2012/ImageSets/Main/trainval.txt"
    f_base = open(base_img_list,"r")
    lines_base = f_base.readlines()
    
    # reduce chongfu base
    count = 0
    for line_base in lines_base:
         print("count:",count)
         count += 1
         base_img_name = line_base.rstrip()
         base_xml_path = anno_path + base_img_name+".xml"                  
         print(base_xml_path)
         labels_all, diffs_all, bboxes_all = reader.load(base_xml_path)

         flag = False
         for k in range(len(labels_all)):
             if labels_all[k] in class_name and diffs_all[k] == 0:
                 flag = True
         if flag:
             for k in range(len(labels_all)):
                     txt_file = list_file + "box_"+shot+"_"+labels_all[k]+"_train.txt"   
                     if labels_all[k] in class_name and diffs_all[k] == 0:
                         if dict_num[labels_all[k]] >= shot_num:
                             break
                         dict_num[labels_all[k]]+=1
                         print(txt_file)
                         f_novel_save = open(txt_file,'a')
                         f_novel_save.write('datasets/VOC2012/JPEGImages/'+base_img_name+'.jpg'+'\n')
                         break

print(dict_num)
