cp -r datasets/coco/trainval2014_gen/* datasets/coco/trainval2014/
