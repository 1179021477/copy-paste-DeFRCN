import numpy as np
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.cluster import SpectralClustering
from transformers import CLIPProcessor, CLIPModel
import json
import os
import torch

img_path = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_200_newrect_cutout_remove/"#_remove
img_list = os.listdir(img_path)
file_save = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_20_newrect_cutout_remove/"

if not os.path.exists(file_save):
   os.makedirs(file_save)

device = "cuda" if torch.cuda.is_available() else "cpu"
token = []
class_name = ["bird","bus","cow","motorbike","sofa", "aeroplane", "bicycle", "boat", "bottle", "car","cat", "chair", "diningtable", "dog", "horse","person", "pottedplant", "sheep", "train", "tvmonitor"]

dict_num = {}
for k in range(len(class_name)):
     dict_num["class_name"] = 0

for k in range(len(class_name)):
    token.append("a "+class_name[k]) 

def cos_sim(x1,x2):
     a = np.dot(x1,x2)
     b1 = np.linalg.norm(x1)
     b2 = np.linalg.norm(x2)
     return a/(b1*b2)

#Clip_model = CLIPModel.from_pretrained(clip_model)
#Processor = CLIPProcessor.from_pretrained(clip_model)

#def get_image_features(image_data):
#    input_data = Processor(image_data)
#    image_features = Clip_model(**input_data).last_hidden_state[0]
#    return image_features.detach().numpy()

#k-means
def kmeans_cluster(data, num_clusters):
    kmeans = KMeans(n_clusters=num_clusters)
    kmeans.fit(data)
    centers = kmeans.cluster_centers_
    labels = kmeans.labels_
    #print(labels,labels.shape)
    return centers,labels

#谱聚类
def spectral_cluster(data, num_clusters):
    model = SpectralClustering(n_clusters=num_clusters)
    labels = model.fit_predict(data)
    centers = []
    for i in range(num_clusters):
        cluster_data = data[labels == i]
        center = np.mean(cluster_data, axis=0)
        centers.append(center)
    return np.array(centers)

#PCA
def Pca(data, num_components):
    pca = PCA(n_components=num_components)
    pca.fit(data)
    components = pca.components_
    return components

#基于欧式距离，选择最远的几个向量：data是包含多个向量的数据
def select_furthest_vectors(data, num_vectors):
    distances = np.array([np.linalg.norm(data - vector, axis=1) for vector in data])
    furthest_indexes = np.argsort(np.max(distances, axis=1))[-num_vectors:]
    return data[furthest_indexes]

f = open("./image_feature.txt","r")
class_name = {"bird":[],"bus":[],"cow":[],"motorbike":[],"sofa":[]}
class_name_index = {"bird":[],"bus":[],"cow":[],"motorbike":[],"sofa":[]}
lines = f.readlines()
info = json.loads(lines[0])

fea_list = []
for img in info: 
     #Img = Image.open(img_path+img)
     #img_fea = get_image_features(Img)
     img_fea,probs = info[img]
     print(type(img_fea),np.array(img_fea).shape)
     for key in class_name:
         if key in img:
             class_name[key].append(img_fea)
             class_name_index[key].append(img)
     #fea_list.append(img_fea)
print("lenlen:",len(class_name["bird"]))

#fea_list = np.array(fea_list).squeeze(1)  
#print(fea_list.shape)
final_list = []
for key in class_name:
     fea_list = np.array(class_name[key]).squeeze(1)
     print(fea_list.shape)#250,512
     #centers,labels = kmeans_cluster(fea_list,20)
     centers = spectral_cluster(fea_list,20)
     #centers = select_furthest_vectors(fea_list,20)
     print(centers.shape)#(20,512)
     for c in centers:
         select = []
         for f in fea_list:
              score = cos_sim(f,c.T)
              select.append(score)
         
         select = np.array(select)
         index = np.argmin(select)#min
         print("c:",select[index])
         img_name = class_name_index[key][index]
         final_list.append(img_name)

print(len(final_list))
print(final_list)
import shutil
#img_path = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_200_newrect_cutout_remove/"
#file_save = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_20_newrect_cutout_remove/"

for f in final_list:
     shutil.copy(img_path+f,file_save+f)

#    print(type(fea),fea.shape)#array #512
#    for c in centers:
        #print(type(c),c.shape)#array #512
#        print(fea)
#        print(c)
#        if (c == fea).all():
#            print("true")
    
