import json
import copy
from pycocotools.coco import COCO

coco_img = "trainval_base_img.json"
coco_anno = "trainval_base_annos.json"

f1 = open(coco_img,"r")
f = open(coco_anno,"r")
anno_infos = json.load(f)
f.close()

anno_infos["images"] = json.load(f1)["images"]
print(len(anno_infos["images"]),len(anno_infos["annotations"]))
f1.close()

f = open("trainval_base.json","w")
f.write(json.dumps(anno_infos))
f.close()
