import json
import copy
from pycocotools.coco import COCO

coco_anno = "./trainvalno5k.json"
coco = COCO(coco_anno)

f = open(coco_anno,"r")
infos = json.load(f)
label = [1, 2, 3, 4, 5, 6, 7, 9, 16, 17, 18, 19, 20, 21, 44, 62, 63, 64, 67, 72]

print(len(infos["images"]),len(infos["annotations"]))
imgs = infos["images"]
annos = infos["annotations"]

new_infos = copy.deepcopy(infos)
new_infos["images"] = []
new_infos["annotations"] = []

imgs_str = json.dumps(imgs)
annos_str = json.dumps(annos)
new_img_id = []
for i in range(len(annos)):
    cat_id = annos[i]["category_id"]
    if cat_id in label:
      image_id = annos[i]["image_id"]
      new_img_id.append(image_id)
      #break
print(len(new_img_id))

#for i in range(len(annos)):
#   img_id = annos[i]["image_id"]
#   if img_id not in new_img_id:
#      new_infos["annotations"].append(annos[i])
#print(len(new_infos["annotations"]))

for i in range(len(imgs)):
   img_info = imgs[i]
   if img_info["id"] not in new_img_id:
      print(i)
      new_infos["images"].append(img_info)

print(len(new_infos["images"]),len(new_infos["annotations"]))
f.close()
f = open("trainval_base_img.json","w")
f.write(json.dumps(new_infos))
