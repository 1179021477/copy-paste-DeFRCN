import os
import json
import shutil
import cv2
from pycocotools.coco import COCO

res_file = "checkpoints/coco/baseline_coco/defrcn_fsod_r101_novel/fsrw-like/30shot_seed0_repeat0/inference/coco_instances_results_base.json"
f = open(res_file,"r")
res_info = json.load(f)
print("len info:",len(res_info))

coco_anno = "datasets/cocosplit/datasplit/trainvalno5k-origin.json"#5k.json
coco = COCO(coco_anno)

clip_imgs = "CLIP-main/select_imgs_coco_softmax0.5_novelclass/"
clip_list = os.listdir(clip_imgs)

f_save = open("base_list/select_base_coco_30shot_0.6_clipremove_3.txt","a")

base = []
#base_lines = f_base.readlines()

img_path = "datasets/coco/trainval2014/"
new_path = "select_imgs_coco/"
if not os.path.exists(new_path):
    os.makedirs(new_path)

select_base = []
count = 0
label = [1, 2, 3, 4, 5, 6, 7, 9, 16, 17, 18, 19, 20, 21, 44, 62, 63, 64, 67, 72]
#label = [4]
thresh = 0.6
thresh_low = 0.5

nums_list = {} #{"15":0,"16":0,"17":0,"18":0,"19":0}
for i in range(len(label)):
    nums_list[str(label[i])] = 0
print(len(label),nums_list)

num_thresh = 3-1 #10000000 #3-1

wrong_label_list = []
count_img = []
image_id_list = []

for m in range(len(res_info)):
        info = res_info[m]
        image_id = info["image_id"]
        cat_id = info["category_id"]
        bbox = info["bbox"]
        score = info["score"]
        #print(info)
        if int(cat_id) in label and score > thresh: # and score > thresh_low:
           if nums_list[str(cat_id)] > num_thresh: 
              continue

           print(nums_list)
           img_info = coco.loadImgs(ids=image_id)
           print(cat_id, image_id, img_info)
      
           img_name = img_info[0]["file_name"]

           if [img_name,cat_id] in count_img or img_name in clip_list:
              continue

           count_img.append([img_name,cat_id])
           select_base.append(img_name)
           nums_list[str(cat_id)] += 1
           count += 1
           wrong_label_list.append(cat_id) 
           image_id_list.append(image_id)
 
           [x1,y1,w,h] = bbox
           img = cv2.imread(img_path+"/"+img_name)
           x1 = float(x1)
           y1 = float(y1)
           x2 = float(x1+w)
           y2 = float(y1+h)
           cv2.rectangle(img,(int(x1),int(y1)),(int(x2),int(y2)),(255,0,0),2)
           cv2.putText(img, str(cat_id), (int(x1), int(y1)), cv2.FONT_HERSHEY_COMPLEX, 0.8, (0, 255, 0), 2)
           cv2.imwrite(new_path+"/"+img_name,img)
          #break

print("num:",len(select_base),len(wrong_label_list))
print(nums_list)
prefix = "datasets/coco/trainval2014/"
count = 0
for k in select_base:
    img_name = k
    f_save.write(prefix+img_name+" "+str(wrong_label_list[count])+" "+str(image_id_list[count])+"\n")
    count += 1
    #shutil.copy(img_path+img_name, new_path+"/"+img_name)

