import os
import json
#get image id of base images that have novel classes from coco-pretrained model
file_list = "up_coco_pretrained_base/results_dir/ret18/results.txt"
f = open(file_list,"r")
f_save = open("coco_pretrained_novel.txt","a")
lines = f.readlines()
count = 0
novel_classes = [1, 2, 3, 4, 5, 6, 7, 9, 16, 17, 18, 19, 20, 21,
                               44, 62, 63, 64, 67, 72]
save_info = {"image_id":[]}
for line in lines:
    info = json.loads(line)
    cat_id = info["category_id"]
    score = info["score"]
    image_id = info["image_id"]
    if cat_id in novel_classes and score > 0.5:
         count += 1
         save_info["image_id"].append(image_id)
         print(count)

f_save.write(json.dumps(save_info))
