from .builtin import register_all_voc, register_all_coco
