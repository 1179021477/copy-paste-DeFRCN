# -*- coding: utf-8 -*-
import os
import torch
import logging
import tempfile
import numpy as np
from functools import lru_cache
from xml.etree import ElementTree as ET
from collections import OrderedDict, defaultdict
from detectron2.utils import comm
from detectron2.data import MetadataCatalog
from detectron2.utils.logger import create_small_table
from defrcn.evaluation.evaluator import DatasetEvaluator
from PIL import Image
from transformers import CLIPProcessor, CLIPModel

device = "cuda" if torch.cuda.is_available() else "cpu"
token = []
class_name = ["bird","bus","cow","motorbike","sofa", "aeroplane", "bicycle", "boat", "bottle", "car","cat", "chair", "diningtable", "dog", "horse","person", "pottedplant", "sheep", "train", "tvmonitor"]

for k in range(len(class_name)):
    token.append("a "+class_name[k]) 

clip_model = "./CLIP-main/clip-vit-base-patch32/"
Clip_model = CLIPModel.from_pretrained(clip_model)
Processor = CLIPProcessor.from_pretrained(clip_model)

class PascalVOCDetectionEvaluator(DatasetEvaluator):
    """
    Evaluate Pascal VOC AP.
    It contains a synchronization, therefore has to be called from all ranks.

    Note that this is a rewrite of the official Matlab API.
    The results should be similar, but not identical to the one produced by
    the official API.
    """

    def __init__(self, dataset_name):
        """
        Args:
            dataset_name (str): name of the dataset, e.g., "voc_2007_test"
        """
        self._dataset_name = dataset_name
        meta = MetadataCatalog.get(dataset_name)
        self._anno_file_template = os.path.join(meta.dirname, "Annotations", "{}.xml")
        self._image_set_path = os.path.join(meta.dirname, "ImageSets", "Main", meta.split + ".txt")
        self._class_names = meta.thing_classes
        # add this two terms for calculating the mAP of different subset
        self._base_classes = meta.base_classes
        self._novel_classes = meta.novel_classes
        assert meta.year in [2007, 2012], meta.year
        self._is_2007 = meta.year == 2007
        self._cpu_device = torch.device("cpu")
        self._logger = logging.getLogger(__name__)

    def reset(self):
        self._predictions = defaultdict(list)  # class name -> list of prediction strings

    def process(self, inputs, outputs):
        for input, output in zip(inputs, outputs):
            image_id = input["image_id"]
            instances = output["instances"].to(self._cpu_device)
            boxes = instances.pred_boxes.tensor.numpy()
            scores = instances.scores.tolist()
            classes = instances.pred_classes.tolist()
            for box, score, cls in zip(boxes, scores, classes):
                xmin, ymin, xmax, ymax = box
                # The inverse of data loading logic in `datasets/pascal_voc.py`
                xmin += 1
                ymin += 1
                self._predictions[cls].append(
                    f"{image_id} {score:.3f} {xmin:.1f} {ymin:.1f} {xmax:.1f} {ymax:.1f}"
                )

    def evaluate(self):
        """
        Returns:
            dict: has a key "segm", whose value is a dict of "AP", "AP50", and "AP75".
        """
        all_predictions = comm.gather(self._predictions, dst=0)
        #print("all_pred:",len(all_predictions),all_predictions) #list
        #self._logger.info("all_pred:+\n",all_predictions)
        #[dict(<class 'list'>, {4: ['000001 0.390 32.0 60.5 353.0 473.6'       
        import copy
        import json
        f = open("test_res.txt","w")
        results = copy.deepcopy(all_predictions)
        #new_results = {} 
        #print(results)

        #for per_rank in results:
        #   for clsid, lines in per_rank.items():
                #print(str(lines),str(clsid))
        #        print(len(per_rank.items()),type(lines),clsid)# 5 class dict (0-4)
   
        #for k in range(len(results)):
        #     if k == 0:
        #         print(type(results[k]))
        #     info = str(results[k]).split(" ")
             #print(str(info)+"\n")
        #     id_ = info[0]
        #     if not id_ in new_results.keys():
        #         new_results[id_] = [[info]]
        #     else:
        #         new_results[id_].append([info])
             #print("###:",new_results[id_])
        #final_res = []
        #count = 0
        #for i in new_results.keys(): 
        #     info_new = new_results[i]
        #     final_res.append([])    
        #     for j in range(len(info_new)):
        #         final_res[count].append(info_new[j])
        #     count += 1
        #print("res:",len(final_res),final_res[-1])

        #info_1 = {"final_res":final_res}
        #f.write(json.dumps(info_1).replace("\n","").replace(" ","")+"\n")
        #f.write(str(all_predictions))

        if not comm.is_main_process():
            return
        predictions = defaultdict(list)
        for predictions_per_rank in all_predictions:
            for clsid, lines in predictions_per_rank.items():
                predictions[clsid].extend(lines)

        save_pred = {"0":[],"1":[],"2":[],"3":[],"4":[]}
        for pred in all_predictions:
            for cls, lines in pred.items():
             #   print(str(lines)+"\n")
                new_lines = str(lines).replace("[","").replace("]","").replace("\n","").replace("'","")
                info = new_lines.split(", ")
                for k in range(len(info)):
              #      print(info[k])
                    #temp = []
                    fo = info[k].split(" ")
                    #print(fo)
                    save_pred[str(cls)].append(fo)
 
        #print(self._image_set_path)               
        f.write(json.dumps(save_pred))

        f_clip = open("test_res_clip.txt","w")
        del all_predictions

        self._logger.info(
            "Evaluating {} using {} metric. "
            "Note that results do not use the official Matlab API.".format(
                self._dataset_name, 2007 if self._is_2007 else 2012
            )
        )

        with tempfile.TemporaryDirectory(prefix="pascal_voc_eval_") as dirname:
            #print("dirname:",dirname)#/tmp
            res_file_template = os.path.join(dirname, "{}.txt")

            aps = defaultdict(list)  # iou -> ap per class
            tps = defaultdict(list)
            fps = defaultdict(list)
            aps_base = defaultdict(list)
            aps_novel = defaultdict(list)
            fps_novel = defaultdict(list)
            tps_novel = defaultdict(list)
            exist_base, exist_novel = False, False

            img_full_path = "datasets/VOC2007/JPEGImages/"
            #new_lines = []
            print(len(self._class_names))
            save_clip = {}
            for cls_id, cls_name in enumerate(self._class_names):
                lines = predictions.get(cls_id, [""])
                # add clip model
                print("eval:",cls_name)#10243 instance 
                new_lines = []
                for l in lines:
                    infos = l.split(" ")
                    Img = Image.open(img_full_path+infos[0]+".jpg")
                    score = float(infos[1])
                    xmin = int(float(infos[2]))
                    ymin = int(float(infos[3]))
                    xmax = int(float(infos[4]))
                    ymax = int(float(infos[5]))
                    Img = Img.crop((xmin,ymin,xmax,ymax))
    
                    inputs = Processor(text=token, images=Img, return_tensors="pt", padding=True)
                    outputs = Clip_model(**inputs)
                    logits_per_image = outputs.logits_per_image # this is the image-text similarity score
                    probs = logits_per_image.softmax(dim=1) # we can take the softmax to get the label probabilities
                    if probs[0][cls_id] >= 0.2: #== max(probs[0]): #>=0.2:
                        new_lines.append(l)
                        #print(probs[0])
                save_clip[cls_id] = new_lines
                lines = new_lines
                with open(res_file_template.format(cls_name), "w") as f:
                    f.write("\n".join(lines))

                for thresh in range(50, 100, 5):
                    rec, prec, ap,tp,fp = voc_eval(
                        res_file_template,
                        self._anno_file_template,
                        self._image_set_path,
                        cls_name,
                        ovthresh=thresh / 100.0,
                        use_07_metric=self._is_2007,
                    )
                    
                        
                    aps[thresh].append(ap * 100)
                    tps[thresh].append(tp)
                    fps[thresh].append(fp)

                    if self._base_classes is not None and cls_name in self._base_classes:
                        aps_base[thresh].append(ap * 100)
                        exist_base = True

                    if self._novel_classes is not None and cls_name in self._novel_classes:
                        aps_novel[thresh].append(ap * 100)
                       # fps_novel[thresh].append(fp * 100)
                       # tps_novel[thresh].append(tp * 100)
                        exist_novel = True
        #print("len**:",aps[50],tps[50])

        f_clip.write(json.dumps(save_clip))
        ret = OrderedDict()
        mAP = {iou: np.mean(x) for iou, x in aps.items()}
        #TP = {tp: np.mean(x) for tp, x in tps.items()}
        #FP = {fp: np.mean(x) for fp, x in fps.items()}

        ret["bbox"] = {"AP": np.mean(list(mAP.values())), "AP50": mAP[50], "AP75": mAP[75]}

        # adding evaluation of the base and novel classes
        if exist_base:
            mAP_base = {iou: np.mean(x) for iou, x in aps_base.items()}
            ret["bbox"].update(
                {"bAP": np.mean(list(mAP_base.values())), "bAP50": mAP_base[50],
                 "bAP75": mAP_base[75]}
            )

        if exist_novel:
            mAP_novel = {iou: np.mean(x) for iou, x in aps_novel.items()}
            ret["bbox"].update({
                "nAP": np.mean(list(mAP_novel.values())), "nAP50": mAP_novel[50],
                "nAP75": mAP_novel[75]
            })

        # write per class AP to logger
        per_class_res = {self._class_names[idx]: ap for idx, ap in enumerate(aps[50])}
       
        per_class_tp = {self._class_names[idx]: int(tp[-1]) for idx, tp in enumerate(tps[50])}
   
        per_class_fp = {self._class_names[idx]: int(fp[-1]) for idx, fp in enumerate(fps[50])}

        #print(len(TP),len(FP))

        #print("tp:"+str(tps[50])+" "+str(len(tps[50][0])))#+" "+str(np.mean(tps[50])))#len(images)
        #self._logger.info("fp:"+str(FP[50]))

        self._logger.info("Evaluate per-class mAP50:\n"+create_small_table(per_class_res))

        self._logger.info("Evaluate per-class TP50:\n"+create_small_table(per_class_tp))
        self._logger.info("Evaluate per-class FP50:\n"+create_small_table(per_class_fp))

        ##111
        self._logger.info("Evaluate overall bbox:\n"+create_small_table(ret["bbox"]))


        #print("len**:",len(list(aps[50][0])))
        ##1
        return ret


##############################################################################
#
# Below code is modified from
# https://github.com/rbgirshick/py-faster-rcnn/blob/master/lib/datasets/voc_eval.py
# --------------------------------------------------------
# Fast/er R-CNN
# Licensed under The MIT License [see LICENSE for details]
# Written by Bharath Hariharan
# --------------------------------------------------------

"""Python implementation of the PASCAL VOC devkit's AP evaluation code."""


@lru_cache(maxsize=None)
def parse_rec(filename):
    """Parse a PASCAL VOC xml file."""
    tree = ET.parse(filename)
    objects = []
    for obj in tree.findall("object"):
        obj_struct = {}
        obj_struct["name"] = obj.find("name").text
        obj_struct["pose"] = obj.find("pose").text
        #obj_struct["truncated"] = int(obj.find("truncated").text)
        obj_struct["difficult"] = int(obj.find("difficult").text)
        bbox = obj.find("bndbox")
        obj_struct["bbox"] = [
            int(bbox.find("xmin").text),
            int(bbox.find("ymin").text),
            int(bbox.find("xmax").text),
            int(bbox.find("ymax").text),
        ]
        objects.append(obj_struct)

    return objects


def voc_ap(rec, prec, use_07_metric=False):
    """Compute VOC AP given precision and recall. If use_07_metric is true, uses
    the VOC 07 11-point method (default:False).
    """
    if use_07_metric:
        # 11 point metric
        ap = 0.0
        for t in np.arange(0.0, 1.1, 0.1):
            if np.sum(rec >= t) == 0:
                p = 0
            else:
                p = np.max(prec[rec >= t])
            ap = ap + p / 11.0
    else:
        # correct AP calculation
        # first append sentinel values at the end
        mrec = np.concatenate(([0.0], rec, [1.0]))
        mpre = np.concatenate(([0.0], prec, [0.0]))

        # compute the precision envelope
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

        # to calculate area under PR curve, look for points
        # where X axis (recall) changes value
        i = np.where(mrec[1:] != mrec[:-1])[0]

        # and sum (\Delta recall) * prec
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def voc_eval(detpath, annopath, imagesetfile, classname, ovthresh=0.5, use_07_metric=False):
    """rec, prec, ap = voc_eval(detpath,
                                annopath,
                                imagesetfile,
                                classname,
                                [ovthresh],
                                [use_07_metric])

    Top level function that does the PASCAL VOC evaluation.

    detpath: Path to detections
        detpath.format(classname) should produce the detection results file.
    annopath: Path to annotations
        annopath.format(imagename) should be the xml annotations file.
    imagesetfile: Text file containing the list of images, one image per line.
    classname: Category name (duh)
    [ovthresh]: Overlap threshold (default = 0.5)
    [use_07_metric]: Whether to use VOC07's 11 point AP computation
        (default False)
    """
    # assumes detections are in detpath.format(classname)
    # assumes annotations are in annopath.format(imagename)
    # assumes imagesetfile is a text file with each line an image name

    # first load gt
    # read list of images
    with open(imagesetfile, "r") as f:
        lines = f.readlines()
    imagenames = [x.strip() for x in lines]

    # load annots
    recs = {}
    for imagename in imagenames:
        recs[imagename] = parse_rec(annopath.format(imagename))

    # extract gt objects for this class
    class_recs = {}
    npos = 0
    for imagename in imagenames:
        R = [obj for obj in recs[imagename] if obj["name"] == classname]
        bbox = np.array([x["bbox"] for x in R])
        difficult = np.array([x["difficult"] for x in R]).astype(np.bool)
        # difficult = np.array([False for x in R]).astype(np.bool)  # treat all "difficult" as GT
        det = [False] * len(R)
        npos = npos + sum(~difficult)
        class_recs[imagename] = {"bbox": bbox, "difficult": difficult, "det": det}

    # read dets
    detfile = detpath.format(classname)
    with open(detfile, "r") as f:
        lines = f.readlines()

    splitlines = [x.strip().split(" ") for x in lines]
    image_ids = [x[0] for x in splitlines]
    confidence = np.array([float(x[1]) for x in splitlines])
    BB = np.array([[float(z) for z in x[2:]] for x in splitlines]).reshape(-1, 4)

    # sort by confidence
    sorted_ind = np.argsort(-confidence)
    BB = BB[sorted_ind, :]
    image_ids = [image_ids[x] for x in sorted_ind]

    # go down dets and mark TPs and FPs
    nd = len(image_ids)
    tp = np.zeros(nd)
    fp = np.zeros(nd)
    for d in range(nd):
        R = class_recs[image_ids[d]]
        bb = BB[d, :].astype(float)
        ovmax = -np.inf
        BBGT = R["bbox"].astype(float)

        if BBGT.size > 0:
            # compute overlaps
            # intersection
            ixmin = np.maximum(BBGT[:, 0], bb[0])
            iymin = np.maximum(BBGT[:, 1], bb[1])
            ixmax = np.minimum(BBGT[:, 2], bb[2])
            iymax = np.minimum(BBGT[:, 3], bb[3])
            iw = np.maximum(ixmax - ixmin + 1.0, 0.0)
            ih = np.maximum(iymax - iymin + 1.0, 0.0)
            inters = iw * ih

            # union
            uni = (
                (bb[2] - bb[0] + 1.0) * (bb[3] - bb[1] + 1.0)
                + (BBGT[:, 2] - BBGT[:, 0] + 1.0) * (BBGT[:, 3] - BBGT[:, 1] + 1.0)
                - inters
            )

            overlaps = inters / uni
            ovmax = np.max(overlaps)
            jmax = np.argmax(overlaps)

        if ovmax > ovthresh:
            if not R["difficult"][jmax]:
                if not R["det"][jmax]:
                    tp[d] = 1.0
                    R["det"][jmax] = 1
                else:
                    fp[d] = 1.0
        else:
            fp[d] = 1.0

    # compute precision recall
    fp = np.cumsum(fp)
    tp = np.cumsum(tp)

    #print("tp:",len(tp),sum(tp))
    #print("fp:",len(fp),sum(fp))
    rec = tp / float(npos)
    # avoid divide by zero in case the first detection matches a difficult
    # ground truth
    prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)
    ap = voc_ap(rec, prec, use_07_metric)

    return rec, prec, ap, tp, fp
