#coding : utf-8
import os
import cv2
import abc
import xml.dom.minidom as xml
import math
import matplotlib.pyplot as plt
from PIL import Image

from save_xml import save_xml 
import random
import numpy as np
import torch
import torchvision.transforms.functional as TF
import torchvision.transforms as transforms
import copy


'''
read voc xml
'''
 

 
class XmlReader(object):
    __metaclass__ = abc.ABCMeta
    def __init__(self):
        pass
    def read_content(self,filename):
        content = None
        if (False == os.path.exists(filename)):
            return content
        filehandle = None
        try:
            filehandle = open(filename,'rb')
        except FileNotFoundError as e:
            print(e.strerror)
        try:
            content = filehandle.read()
        except IOError as e:
            print(e.strerror)
        if (None != filehandle):
            filehandle.close()
        if(None != content):
            return content.decode("utf-8","ignore")
        return content
 
    @abc.abstractmethod
    def load(self,filename):
        pass
 
class XmlTester(XmlReader):
    def __init__(self):
        XmlReader.__init__(self)
    def load(self, filename):
        filecontent = XmlReader.read_content(self,filename)
        if None != filecontent:
            dom = xml.parseString(filecontent)
            root = dom.getElementsByTagName('annotation')[0]
            #im_size = root.getElementsByTagName('size')[0]
 
            #im_w = int((im_size.getElementsByTagName('width')[0]).childNodes[0].data)
            #im_h = int((im_size.getElementsByTagName("height")[0]).childNodes[0].data)
            #im_shape=[im_w,im_h]
            #print(dom.getElementsByTagName('object'))
            len_objs = len(dom.getElementsByTagName('object'))
            #print("len:",len_objs)
            labels = []
            diffs = []
            bboxs = []
            for i in range(len_objs):
                obj = dom.getElementsByTagName('object')[i]
                box = obj.getElementsByTagName('bndbox')[0]
                #print(obj)
                label = str((obj.getElementsByTagName("name")[0]).childNodes[0].data)
                diff = int((obj.getElementsByTagName("difficult")[0]).childNodes[0].data)
                labels.append(label)
                diffs.append(diff)

                b_xmin=int((box.getElementsByTagName("xmin")[0]).childNodes[0].data)
                b_ymin=int((box.getElementsByTagName("ymin")[0]).childNodes[0].data)
                b_xmax=int((box.getElementsByTagName("xmax")[0]).childNodes[0].data)
                b_ymax=int((box.getElementsByTagName("ymax")[0]).childNodes[0].data)
 
                bbox=[b_xmin,b_ymin,b_xmax,b_ymax]
                bboxs.append(bbox)
  
            return labels, diffs, bboxs
 
 

        
    
 
if __name__ == "__main__":
    class_name = ['bird', 'bus', 'cow', 'motorbike', 'sofa'] #1
    #class_name = ['aeroplane', 'bottle', 'cow', 'horse', 'sofa'] #2
    #class_name = ['boat', 'cat', 'motorbike', 'sheep', 'sofa'] #3
    data_root = "datasets/"
    shot = '5shot'
    list_file = "datasets/vocsplit/seed0/"
    save_img_root = "VOC_novel_instances/split1_"+shot+"/"
    if not os.path.exists(save_img_root):
        os.makedirs(save_img_root)
    files = os.listdir(list_file)
    reader = XmlTester()
     

    novel_list_all = []
    for list_name in files:# novel 
        if (class_name[0] in list_name or class_name[1] in list_name or class_name[2] in list_name or class_name[3] in list_name or class_name[4] in list_name) and shot in list_name:
            #print("list:",list_name)
            f_novel = open(list_file+list_name,'r')
            lines = f_novel.readlines()
            for line in lines: #datasets/VOC2012/JPEGImages/2009_001057.jpg
                #print(line)
                name = line.split("/")[-1]
                pre_fix = line.split('/')[1]
                img = cv2.imread(data_root + pre_fix+"/JPEGImages/"+name.rstrip())
                xml_path = data_root + pre_fix+"/Annotations/"+name.replace(".jpg",".xml").rstrip()
                #print(xml_path)     
                labels,diffs,bboxes=reader.load(xml_path)
                #print("novel:",name, labels,diffs,bboxes)
                
                #get cropped novel instance
                #novel_instances = []
                #novel_labels_list = []
                count = 0
                for cl in range(len(labels)):
                    if labels[cl] in class_name: #novel
                        count += 1
                        [b_xmin,b_ymin,b_xmax,b_ymax] = bboxes[cl]
                        cv_img = img[b_ymin:b_ymax,b_xmin:b_xmax]
                        diff = diffs[cl]                       
                        #novel_instances.append(cv_img)
                        #novel_labels_list.append(labels[cl])
                        #novel_list_all.append({"1":cv_img,"2":labels[cl],"3":pre_fix,"4":name,"5":diff})
                        #print("label:",labels[cl])
                        if int(diff) == 0: 
                             save_img_name = str(count)+name.split('.')[0]+"_"+str(labels[cl])+".jpg"
                             cv2.imwrite(save_img_root+save_img_name,cv_img)


         

 

