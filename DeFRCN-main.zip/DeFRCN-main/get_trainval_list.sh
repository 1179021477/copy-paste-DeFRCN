cp datasets/VOC2007/ImageSets/Main/trainval_split1_base.txt datasets/VOC2007/ImageSets/Main/trainval_all_split1_base.txt &&
cat datasets/VOC2012/ImageSets/Main/trainval_split1_base.txt >> datasets/VOC2007/ImageSets/Main/trainval_all_split1_base.txt
