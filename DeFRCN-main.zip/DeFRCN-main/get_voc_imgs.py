import os
import shutil
list_path = "/nvme/nvme2/linshaobo/DeFRCN-main/datasets/vocsplit/seed0-origin/"
root_path = "/nvme/nvme2/linshaobo/DeFRCN-main/"
save_path = "save_voc_imgs/"

if not os.path.exists(save_path):
    os.makedirs(save_path)
    
files = os.listdir(list_path)

for f in files:
    if "10shot" in f:
       f1 = open(list_path+f,"r")
       c = f.split("_")[2]
       lines = f1.readlines()
       for line in lines:
          n = line.split("/")[-1]
          shutil.copy(root_path+line.rstrip(),save_path+n.split(".")[0]+"_"+c+".jpg")
           