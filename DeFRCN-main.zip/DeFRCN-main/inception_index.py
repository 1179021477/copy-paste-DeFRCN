import numpy as np
import torch
import torchvision
import sys
import torchvision.models as models
import torchvision.transforms as transforms


##This code uses the pre-trained Inception v3 model to extract activations from real and generated images. It then calculates the mean and covariance of the activations for both the real and generated images, and uses those values to compute the FID.


def get_activations(images, model):
    images = torch.autograd.Variable(images, requires_grad=False)
    activations = []
    def hook(module, input, output):
        activations.append(output)
    handle = model.Mixed_7c.register_forward_hook(hook)
    model(images)
    handle.remove()
    return activations[0].view(images.size(0), -1).data.cpu().numpy()

def calculate_mean_covariance(act):
    mean = np.mean(act, axis=0)
    cov = np.cov(act, rowvar=False)
    return mean, cov

def compute_fid(real_images, generated_images):
    # Calculate activations of the real and generated images using the Inception v3 model
    inception_model = torchvision.models.inception_v3(pretrained=True, transform_input=False).eval()
    real_images = torch.Tensor(real_images)
    generated_images = torch.Tensor(generated_images)
    real_act = get_activations(real_images, inception_model)
    generated_act = get_activations(generated_images, inception_model)
    
    # Calculate mean and covariance of the activations
    real_mean, real_cov = calculate_mean_covariance(real_act)
    generated_mean, generated_cov = calculate_mean_covariance(generated_act)
    
    # Compute FID
    diff = real_mean - generated_mean
    fid = diff.dot(diff) + torch.trace(real_cov + generated_cov - 2 * torch.sqrt(torch.mm(real_cov, generated_cov)))
    return fid.item()



def inception_score(images, batch_size=32, resize=None, splits=1):
    """
    Computes the inception score of a set of images using a pretrained Inception v3 model.
    
    Args:
        images (torch.Tensor): a 4D tensor of shape (N, C, H, W), where N is the number of images, 
                              C is the number of channels, H is the height, and W is the width.
        batch_size (int, optional): batch size to use during the computation. Default is 32.
        resize (tuple, optional): if provided, the images will be resized to the specified size 
                                  before being fed into the Inception v3 model. 
                                  Default is None.
        splits (int, optional): number of splits to use for computing the score. Default is 1.
        
    Returns:
        tuple: a tuple containing the mean and standard deviation of the inception score.
    """
    N = len(images)
    
    if resize:
        transform = transforms.Compose([
            transforms.Resize(resize),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
    else:
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        
    images = torch.stack([transform(image) for image in images])
    
    model = models.inception_v3(pretrained=True, aux_logits=False).eval()
    with torch.no_grad():
        preds = np.zeros((N, 1000))
        
        for i in range(0, N, batch_size):
            images_batch = images[i:i+batch_size].to('cuda')
            preds[i:i+batch_size] = torch.nn.functional.softmax(model(images_batch), dim=1).cpu().numpy()
            
        scores = []
        for i in range(splits):
            part = preds[i * (N // splits): (i + 1) * (N // splits), :]
            kl = part * (np.log(part) - np.log(np.expand_dims(np.mean(part, 0), 0)))
            kl = np.mean(np.sum(kl, 1))
            scores.append(np.exp(kl))
            
    return np.mean(scores), np.std(scores)

images = [...] # a list of PIL images
mean, std = inception_score(images)
print("Inception Score: mean={}, std={}".format(mean, std))


