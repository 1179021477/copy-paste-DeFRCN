#coding : utf-8
import os
import cv2
import abc
import xml.dom.minidom as xml
import math
import matplotlib.pyplot as plt
from PIL import Image

from save_xml import save_xml 
import random
import numpy as np
import torch
import torchvision.transforms.functional as TF
import torchvision.transforms as transforms
import copy

#import aug_lib


#from autoaugment import ImageNetPolicy
#from autoaugment import CIFAR10Policy
#from autoaugment import SVHNPolicy

'''
read voc xml
'''
 

 
class XmlReader(object):
    __metaclass__ = abc.ABCMeta
    def __init__(self):
        pass
    def read_content(self,filename):
        content = None
        if (False == os.path.exists(filename)):
            return content
        filehandle = None
        try:
            filehandle = open(filename,'rb')
        except FileNotFoundError as e:
            print(e.strerror)
        try:
            content = filehandle.read()
        except IOError as e:
            print(e.strerror)
        if (None != filehandle):
            filehandle.close()
        if(None != content):
            return content.decode("utf-8","ignore")
        return content
 
    @abc.abstractmethod
    def load(self,filename):
        pass
 
class XmlTester(XmlReader):
    def __init__(self):
        XmlReader.__init__(self)
    def load(self, filename):
        filecontent = XmlReader.read_content(self,filename)
        if None != filecontent:
            dom = xml.parseString(filecontent)
            root = dom.getElementsByTagName('annotation')[0]
            #im_size = root.getElementsByTagName('size')[0]
 
            #im_w = int((im_size.getElementsByTagName('width')[0]).childNodes[0].data)
            #im_h = int((im_size.getElementsByTagName("height")[0]).childNodes[0].data)
            #im_shape=[im_w,im_h]
            #print(dom.getElementsByTagName('object'))
            len_objs = len(dom.getElementsByTagName('object'))
            #print("len:",len_objs)
            labels = []
            diffs = []
            bboxs = []
            for i in range(len_objs):
                obj = dom.getElementsByTagName('object')[i]
                box = obj.getElementsByTagName('bndbox')[0]
                #print(obj)
                label = str((obj.getElementsByTagName("name")[0]).childNodes[0].data)
                diff = int((obj.getElementsByTagName("difficult")[0]).childNodes[0].data)
                labels.append(label)
                diffs.append(diff)

                b_xmin=int((box.getElementsByTagName("xmin")[0]).childNodes[0].data)
                b_ymin=int((box.getElementsByTagName("ymin")[0]).childNodes[0].data)
                b_xmax=int((box.getElementsByTagName("xmax")[0]).childNodes[0].data)
                b_ymax=int((box.getElementsByTagName("ymax")[0]).childNodes[0].data)
 
                bbox=[b_xmin,b_ymin,b_xmax,b_ymax]
                bboxs.append(bbox)
  
            return labels, diffs, bboxs
 
 
def compute_iou(rec1, rec2):
    """
    computing IoU
    :param rec1: (y0, x0, y1, x1), which reflects
            (top, left, bottom, right)
    :param rec2: (y0, x0, y1, x1)
    :return: scala value of IoU
    """
    # computing area of each rectangles
    S_rec1 = (rec1[2] - rec1[0]) * (rec1[3] - rec1[1])
    S_rec2 = (rec2[2] - rec2[0]) * (rec2[3] - rec2[1])
 
    # computing the sum_area
    sum_area = S_rec1 + S_rec2
 
    # find the each edge of intersect rectangle
    left_line = max(rec1[1], rec2[1])
    right_line = min(rec1[3], rec2[3])
    top_line = max(rec1[0], rec2[0])
    bottom_line = min(rec1[2], rec2[2])
 
    # judge if there is an intersect
    if left_line >= right_line or top_line >= bottom_line:
        return 0
    else:
        intersect = (right_line - left_line) * (bottom_line - top_line)
        return (intersect / (sum_area - intersect))*1.0
 
 #aug tricks for novel instances
"""Randomly mask out one or more patches from an image."""
def Cutout(img, n_holes=2, length=32, prob=0.5):
     if np.random.rand() < prob:
            h = img.size(1)
            w = img.size(2)
            mask = np.ones((h, w), np.float32)
            for n in range(n_holes):
                y = np.random.randint(h)
                x = np.random.randint(w)
                y1 = np.clip(y - length // 2, 0, h)
                y2 = np.clip(y + length // 2, 0, h)
                x1 = np.clip(x - length // 2, 0, w)
                x2 = np.clip(x + length // 2, 0, w)
                mask[y1:y2, x1:x2] = 0.

            mask = torch.from_numpy(mask)
            mask = mask.expand_as(img)
            img = img * mask

     return img
        
        
trans = transforms.Compose(
      [ 
        #transforms.RandomCrop(32, padding=4),  #先四周填充0，然后图像随机裁剪成32*32
        #transforms.Resize(),
        #transforms.CenterCrop(),
        #transforms.RandomResizedCrop(),
        #transforms.RandomHorizontalFlip(p=0.5),
        #transforms.RandomVerticalFlip(p=0.1),
        #transforms.RandomRotation(10),
        #ImageNetPolicy(),#auto-augment
        #SVHNPolicy(),
        #CIFAR10Policy(),
        #transforms.ColorJitter(brightness=0.2,contrast=0.2, saturation=0.1),
       ]
)


 
 
if __name__ == "__main__":
    class_name = ['bird', 'bus', 'cow', 'motorbike', 'sofa'] #1
    #class_name = ['aeroplane', 'bottle', 'cow', 'horse', 'sofa'] #2
    #class_name = ['boat', 'cat', 'motorbike', 'sheep', 'sofa'] #3
    data_root = "datasets/"
    shot = '1shot'
    select_num = 20
    list_file = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_100_cutout_remove/"
    base_img_list = "./base_list/select_base-split1-"+shot+"-0.6-100-withlabel.txt"#VOC-base-finetune-split1-1shot.txt"#select_base.txt #VOC2007.txt# use base imgs in novel stage or select full/part of all base data
    files = os.listdir(list_file)
    reader = XmlTester()
    
    #augmenter = aug_lib.TrivialAugment()  

    novel_list_all = []
    for name in files:# novel 
              img = cv2.imread(list_file+name)
              for cl in range(len(class_name)):
                   if class_name[cl] in name: #novel                      
                       #novel_instances.append(img)
                       #novel_labels_list.append(class_name[cl])
                       novel_list_all.append({"1":img,"2":class_name[cl],"3":"VOC2007","4":name,"5":0})
                       #print("label:",labels[cl])

    temo_list = novel_list_all
    novel_list_all = []
                        
    for i in range(len(class_name)):
        for j in range(len(temo_list)):
            if temo_list[j]["2"] == class_name[i]:
                 novel_list_all.append(temo_list[j])

    print(novel_list_all)                 
           #base img list
    f_base = open(base_img_list,"r")
    lines_base = f_base.readlines()

     # reduce chongfu base
    count = 0
    base_list_all = []
    for line_base in lines_base:
         #print("count:",count,line_base)
         count += 1
         pre_fix = line_base.split(" ")[0].split("/")[1]
         base_img_name = line_base.split(" ")[0].split("/")[-1]
         wrong_label = int(line_base.split(" ")[1].rstrip())
         base_path = data_root + pre_fix+"/JPEGImages/"+base_img_name.rstrip()
         #print(base_path)
         base_img = cv2.imread(base_path)
         base_xml_path = data_root + pre_fix+"/Annotations/"+base_img_name.replace(".jpg",".xml").rstrip()
                    
         #H,W,C = base_img.shape    
 
         base_labels_all, base_diff_all, base_bboxes_all = reader.load(base_xml_path)
         base_list_all.append({"1":base_img,"2":base_bboxes_all,"3":wrong_label,"4":base_xml_path,"5":base_img_name}) 

    dict_b = {"15":[],"16":[],"17":[],"18":[],"19":[]}
    dict_num = {"15":0,"16":0,"17":0,"18":0,"19":0}

    for k in range(len(base_list_all)):
          dict_b[str(base_list_all[k]["3"])].append({"base_img":base_list_all[k]["1"],"bboxes":base_list_all[k]["2"],"base_xml_path":base_list_all[k]["4"],"base_img_name":base_list_all[k]["5"]})  
    #print(dict_b["16"]) 
    count_k = 0
    #print(len(novel_list_all))
    for i in range(5):
        print(len(dict_b[str(i+15)]))

    for k in range(len(novel_list_all)):
         #print(k)
         novel_instances = novel_list_all[k]["1"]
         novel_labels_list = novel_list_all[k]["2"]
         pre_fix = novel_list_all[k]["3"]
         name = novel_list_all[k]["4"]
         diffs = novel_list_all[k]["5"]
         save_root = data_root + pre_fix+"/Annotations_1/"
         save_img_root = data_root + pre_fix+"/JPEGImages_1/"
         if not os.path.exists(save_root):
              os.makedirs(save_root)
         if not os.path.exists(save_img_root):
              os.makedirs(save_img_root)

         # resized instance ratio of base img           
         object_ratio = random.uniform(2,5)            
         #print(novel_labels_list)        
         #for i in range(len(novel_instances)): # only select one novel sample
         #      if diffs[i] == 0:
                  #n = random.randint(0,len(novel_instances)-1)
         #          n = i
         if int(diffs) == 0: 
           novel_i = novel_instances#[n]
           novel_label_list = novel_labels_list#[n]
           w_1 = novel_i.shape[1]
           h_1 = novel_i.shape[0]
           tr = class_name.index(novel_label_list)+15
         
           sel = len(dict_b[str(tr)]) #select base pre class

           if sel == 0:
               continue
           # make sure num base <= num novel
           if dict_num[str(tr)] == sel:
               k1 = 0
               count_k = 0
               continue
           if dict_num[str(tr)] >= select_num:
               continue             

           if count_k % sel == 0:
             k1 = 0
           else:
             k1 += 1
           dict_num[str(tr)] += 1
           count_k += 1
           print("dict-num:",dict_num)
           import copy
           if k1 > len(dict_b[str(tr)]):
               k1 = 0
           print(k1,len(dict_b[str(tr)]))
           
           for m in range(k1, len(dict_b[str(tr)])):
            base_img =  copy.deepcopy(dict_b[str(tr)][m]["base_img"])    
            base_bboxes_all =  dict_b[str(tr)][m]["bboxes"] 
            base_xml_path = dict_b[str(tr)][m]["base_xml_path"]
            base_img_name = dict_b[str(tr)][m]["base_img_name"]
            H,W,C = base_img.shape              
 
           #avoid filling the base instances: by gen 100 box find min sum of iou novel box with  all base boxes
            all_novel_list = []
            novel_bboxs_list = []
            tmp_list = []
            use_ratio = True
            #print("111111111111")
            for k in range(1000):
                 if use_ratio:
                     tmp = cv2.resize(novel_instances,(int(W/object_ratio),int(H/object_ratio))) # how to resize:keep novel ratio or others
                     loc_xmin = random.randint(1,W-int(W/object_ratio))
                     loc_ymin = random.randint(1,H-int(H/object_ratio))
                     w_o = tmp.shape[1] #int(W/object_ratio)
                     h_o = tmp.shape[0] 
                     bboxes = [loc_ymin,loc_xmin,loc_ymin+h_o,loc_xmin+w_o]
                     novel_bboxs_list.append([loc_xmin,loc_ymin,loc_xmin+w_o,loc_ymin+h_o])
                     all_novel_list.append(bboxes)
                     tmp_list.append(tmp)

            iou_list = []
            for m in range(len(all_novel_list)):
                   rec1 = all_novel_list[m]
                   iou = 0
                   for j in range(len(base_bboxes_all)):  
                        [b_xmin,b_ymin,b_xmax,b_ymax] = base_bboxes_all[j]
                        rec2 = [b_ymin,b_xmin,b_ymax,b_xmax]
                        iou  += compute_iou(rec1, rec2)  
                   iou_list.append(iou) 
            min_index = np.argmin(np.array(iou_list))                     
            tmp = tmp_list[min_index]

            novel_bbox_list = novel_bboxs_list[min_index]
            loc_ymin = novel_bbox_list[1]
            loc_xmin = novel_bbox_list[0]
            ymax = novel_bbox_list[3]
            xmax = novel_bbox_list[2]
				
            #print("xxxx:",loc_ymin)
            #mix img # 1 on 1
 
            base_img[loc_ymin:ymax,loc_xmin:xmax] = tmp
				  
            save_img_name = base_img_name.split('.')[0]+name.split('.')[0]+"_"+str(count_k)+".jpg"
				#mix img # more on 1
				#print(save_img_name) 
				
            cv2.imwrite(save_img_root+save_img_name,base_img) 
				 
            labels_base,diffs_base,bboxs_base=reader.load(base_xml_path)
            #print("###",novel_label_list,novel_bbox_list)
            save_xml(W,H,labels_base,diffs_base,bboxs_base,save_img_name,save_root, novel_label_list, novel_bbox_list) 
            base_img = None
            break
 
