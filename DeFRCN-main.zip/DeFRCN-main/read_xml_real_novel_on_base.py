#coding : utf-8
import os
import cv2
import abc
import xml.dom.minidom as xml
import math
import matplotlib.pyplot as plt
from PIL import Image

from save_xml import save_xml 
import random
import numpy as np
import torch
import torchvision.transforms.functional as TF
import torchvision.transforms as transforms
import copy

#import aug_lib


#from autoaugment import ImageNetPolicy
#from autoaugment import CIFAR10Policy
#from autoaugment import SVHNPolicy

'''
read voc xml
'''
 

 
class XmlReader(object):
    __metaclass__ = abc.ABCMeta
    def __init__(self):
        pass
    def read_content(self,filename):
        content = None
        if (False == os.path.exists(filename)):
            return content
        filehandle = None
        try:
            filehandle = open(filename,'rb')
        except FileNotFoundError as e:
            print(e.strerror)
        try:
            content = filehandle.read()
        except IOError as e:
            print(e.strerror)
        if (None != filehandle):
            filehandle.close()
        if(None != content):
            return content.decode("utf-8","ignore")
        return content
 
    @abc.abstractmethod
    def load(self,filename):
        pass
 
class XmlTester(XmlReader):
    def __init__(self):
        XmlReader.__init__(self)
    def load(self, filename):
        filecontent = XmlReader.read_content(self,filename)
        if None != filecontent:
            dom = xml.parseString(filecontent)
            root = dom.getElementsByTagName('annotation')[0]
            #im_size = root.getElementsByTagName('size')[0]
 
            #im_w = int((im_size.getElementsByTagName('width')[0]).childNodes[0].data)
            #im_h = int((im_size.getElementsByTagName("height")[0]).childNodes[0].data)
            #im_shape=[im_w,im_h]
            #print(dom.getElementsByTagName('object'))
            len_objs = len(dom.getElementsByTagName('object'))
            #print("len:",len_objs)
            labels = []
            diffs = []
            bboxs = []
            for i in range(len_objs):
                obj = dom.getElementsByTagName('object')[i]
                box = obj.getElementsByTagName('bndbox')[0]
                #print(obj)
                label = str((obj.getElementsByTagName("name")[0]).childNodes[0].data)
                diff = int((obj.getElementsByTagName("difficult")[0]).childNodes[0].data)
                labels.append(label)
                diffs.append(diff)

                b_xmin=int((box.getElementsByTagName("xmin")[0]).childNodes[0].data)
                b_ymin=int((box.getElementsByTagName("ymin")[0]).childNodes[0].data)
                b_xmax=int((box.getElementsByTagName("xmax")[0]).childNodes[0].data)
                b_ymax=int((box.getElementsByTagName("ymax")[0]).childNodes[0].data)
 
                bbox=[b_xmin,b_ymin,b_xmax,b_ymax]
                bboxs.append(bbox)
  
            return labels, diffs, bboxs
 
 
def compute_iou(rec1, rec2):
    """
    computing IoU
    :param rec1: (y0, x0, y1, x1), which reflects
            (top, left, bottom, right)
    :param rec2: (y0, x0, y1, x1)
    :return: scala value of IoU
    """
    # computing area of each rectangles
    S_rec1 = (rec1[2] - rec1[0]) * (rec1[3] - rec1[1])
    S_rec2 = (rec2[2] - rec2[0]) * (rec2[3] - rec2[1])
 
    # computing the sum_area
    sum_area = S_rec1 + S_rec2
 
    # find the each edge of intersect rectangle
    left_line = max(rec1[1], rec2[1])
    right_line = min(rec1[3], rec2[3])
    top_line = max(rec1[0], rec2[0])
    bottom_line = min(rec1[2], rec2[2])
 
    # judge if there is an intersect
    if left_line >= right_line or top_line >= bottom_line:
        return 0
    else:
        intersect = (right_line - left_line) * (bottom_line - top_line)
        return (intersect / (sum_area - intersect))*1.0
 
 #aug tricks for novel instances
"""Randomly mask out one or more patches from an image."""
def Cutout(img, n_holes=2, length=32, prob=0.5):
     if np.random.rand() < prob:
            h = img.size(1)
            w = img.size(2)
            mask = np.ones((h, w), np.float32)
            for n in range(n_holes):
                y = np.random.randint(h)
                x = np.random.randint(w)
                y1 = np.clip(y - length // 2, 0, h)
                y2 = np.clip(y + length // 2, 0, h)
                x1 = np.clip(x - length // 2, 0, w)
                x2 = np.clip(x + length // 2, 0, w)
                mask[y1:y2, x1:x2] = 0.

            mask = torch.from_numpy(mask)
            mask = mask.expand_as(img)
            img = img * mask

     return img
        
        
trans = transforms.Compose(
      [ 
        #transforms.RandomCrop(32, padding=4),  #先四周填充0，然后图像随机裁剪成32*32
        #transforms.Resize(),
        #transforms.CenterCrop(),
        #transforms.RandomResizedCrop(),
        #transforms.RandomHorizontalFlip(p=0.5),
        #transforms.RandomVerticalFlip(p=0.1),
        #transforms.RandomRotation(10),
        #ImageNetPolicy(),#auto-augment
        #SVHNPolicy(),
        #CIFAR10Policy(),
        #transforms.ColorJitter(brightness=0.2,contrast=0.2, saturation=0.1),
       ]
)


 
 
if __name__ == "__main__":


    class_name = ['bird', 'bus', 'cow', 'motorbike', 'sofa'] #1
    #class_name = ['aeroplane', 'bottle', 'cow', 'horse', 'sofa'] #2
    #class_name = ['boat', 'cat', 'motorbike','sheep','sofa']#3

    import argparse
    parser = argparse.ArgumentParser(description='subcommand for getting frames')
    parser.add_argument('-s', help='shot') #1 to 10
    parser.add_argument('-n',help='select_num') #1 to 1000
    #parser.add_argument('-f',help='list file') #none a a1 one one1 real
    args = parser.parse_args()
    print(args)

    data_root = "datasets/"
    shot = args.s + 'shot'
    select_num = int(args.n)

    list_file = "datasets/vocsplit/seed0/"
    reader = XmlTester()
    
    anno_path = ["datasets/VOC2007/Annotations/","datasets/VOC2012/Annotations/"]
    img_list = ["datasets/VOC2007/ImageSets/Main/trainval.txt","datasets/VOC2012/ImageSets/Main/trainval.txt"]
    base_img_list = ["datasets/VOC2007/ImageSets/Main/trainval_base.txt", "datasets/VOC2012/ImageSets/Main/trainval_base.txt"]
    novel_img_list = ["datasets/VOC2007/ImageSets/Main/trainval_novel.txt","datasets/VOC2012/ImageSets/Main/trainval_novel.txt"]
    
    #for k in range(len(img_list)):
    #  f_all = open(img_list[k],"r")
    #  lines_all = f_all.readlines()
    #  f_base = open(base_img_list[k],"a")
    #  f_novel = open(novel_img_list[k],"a")

    #  count_b = 0
    #  count_n = 0
    #  for line_all in lines_all:
         #print("count:",k)
    #     img_name = line_all.rstrip()
    #     xml_path = anno_path[k] + img_name+".xml"                  
    #     labels_all, diffs_all, bboxes_all = reader.load(xml_path)
    #     flag = False
    #     for m in range(len(labels_all)):
    #         if labels_all[m] in class_name and diffs_all[m] == 0:
    #                f_novel.write(line_all)
    #                flag = True
    #                count_n += 1
    #                break
    #     if not flag:
    #         count_b += 1
    #         f_base.write(line_all) 
    #  print(k,count_b,count_n)              
 # 1 3888 1123
 # 2 9k 2509   
 
    novel_list_all = []

    dict_n = {"15":0,"16":0,"17":0,"18":0,"19":0}
    count_n = 0
    for k in range(len(img_list)):
      #count_n = 0
      f_novel = open(novel_img_list[k],"r")
      lines = f_novel.readlines()
      if k == 0:
          pre_fix = "VOC2007"
      else:
          pre_fix = "VOC2012"
     
      
      for line in lines:
                name = line.rstrip()
                xml_path = anno_path[k] + name+".xml" 
                img = cv2.imread(data_root + pre_fix+"/JPEGImages/"+name+".jpg")   
                labels,diffs,bboxes=reader.load(xml_path)
                #print("novel:",name, labels,diffs,bboxes)
                count_n += 1
                #get cropped novel instance
                novel_instances = []
                novel_labels_list = []
                for cl in range(len(labels)):
                    if labels[cl] in class_name: #novel
                        [b_xmin,b_ymin,b_xmax,b_ymax] = bboxes[cl]
                        cv_img = img[b_ymin:b_ymax,b_xmin:b_xmax]
                        novel_instances.append(cv_img)
                        novel_labels_list.append(labels[cl])
                        diff = diffs[cl]
                        novel_list_all.append({"1":cv_img,"2":labels[cl],"3":pre_fix,"4":name,"5":diff})
                        #print("label:",labels[cl])
                        dict_n[str(class_name.index(labels[cl])+15)] += 1

    print("dict_n:",count_n, dict_n)#3.6k,{15:1803,16:887,17:1040,18:1126,19:870}
    temo_list = novel_list_all
    novel_list_all = []
                        
    for i in range(len(class_name)):
        for j in range(len(temo_list)):
            if temo_list[j]["2"] == class_name[i]:
                 novel_list_all.append(temo_list[j])

    print("len(novel_list_all):",len(novel_list_all))#5.7k                 

    f_base = open(base_img_list[0],"r")
    lines_base = f_base.readlines()
    print(base_img_list[0])
    # reduce chongfu base
    count = 0
    base_list_all = []
    for line_base in lines_base:
         count += 1
         base_img_name = line_base.rstrip()
         base_xml_path = anno_path[0] + base_img_name+".xml" 
         base_img = cv2.imread(data_root + "/VOC2007/JPEGImages/"+base_img_name+".jpg")  
         base_labels_all, base_diff_all, base_bboxes_all = reader.load(base_xml_path)
         base_list_all.append({"1":base_img,"2":base_bboxes_all,"4":base_xml_path,"5":base_img_name}) 
    print("base_list_all:",len(base_list_all))#5k

    #dict_b = {"15":[],"16":[],"17":[],"18":[],"19":[]}
    dict_num = {"15":0,"16":0,"17":0,"18":0,"19":0}
    count_k = 0
    for k in range(len(novel_list_all)):
         #print(k)
         novel_instances = novel_list_all[k]["1"]
         novel_label_list = novel_list_all[k]["2"]
         pre_fix = novel_list_all[k]["3"]
         name = novel_list_all[k]["4"]
         diffs = novel_list_all[k]["5"]
         save_root = data_root + "/VOC2007/Annotations_1/"
         save_img_root = data_root + "/VOC2007/JPEGImages_1/"
         if not os.path.exists(save_root):
              os.makedirs(save_root)
         if not os.path.exists(save_img_root):
              os.makedirs(save_img_root)

         # resized instance ratio of base img           
         object_ratio = random.uniform(2,5)            
         if int(diffs) == 0: 
           tr = class_name.index(novel_label_list)+15
           #sel = len(dict_b[str(tr)]) #select base pre class

           if dict_num[str(tr)] >= select_num:
               continue             
           dict_num[str(tr)] += 1
           print("dict-num:", dict_num)
           count_k += 1
           import copy       
          
           # paste
           base_img = copy.deepcopy(base_list_all[count_k]["1"])    
           base_bboxes_all =  base_list_all[count_k]["2"] 
           base_xml_path = base_list_all[count_k]["4"]
           base_img_name = base_list_all[count_k]["5"]
           H,W,C = base_img.shape 
           #H1,W1,C = novel_instances.shape            
           H1 = H
           W1 = W
           #print(H,W)
           #avoid filling the base instances: by gen 100 box find min sum of iou novel box with  all base boxes
           all_novel_list = []
           novel_bboxs_list = []
           tmp_list = []
           use_ratio = True
           for k in range(1000):
                 if use_ratio:
                     tmp = cv2.resize(novel_instances,(int(W1/object_ratio),int(H1/object_ratio))) # how to resize:keep novel ratio or others                      
                     loc_xmin = random.randint(1,W-int(W1/object_ratio))
                     loc_ymin = random.randint(1,H-int(H1/object_ratio))
                     w_o = tmp.shape[1] 
                     h_o = tmp.shape[0] 
                     bboxes = [loc_ymin,loc_xmin,loc_ymin+h_o,loc_xmin+w_o]
                     novel_bboxs_list.append([loc_xmin,loc_ymin,loc_xmin+w_o,loc_ymin+h_o])
                     all_novel_list.append(bboxes)
                     tmp_list.append(tmp)

           iou_list = []
           for m in range(len(all_novel_list)):
                   rec1 = all_novel_list[m]
                   iou = 0
                   for j in range(len(base_bboxes_all)):  
                        [b_xmin,b_ymin,b_xmax,b_ymax] = base_bboxes_all[j]
                        rec2 = [b_ymin,b_xmin,b_ymax,b_xmax]
                        iou  += compute_iou(rec1, rec2)  
                   iou_list.append(iou) 
           min_index = np.argmin(np.array(iou_list))                     
           tmp = tmp_list[min_index]

           novel_bbox_list = novel_bboxs_list[min_index]
           loc_ymin = novel_bbox_list[1]
           loc_xmin = novel_bbox_list[0]
           ymax = novel_bbox_list[3]
           xmax = novel_bbox_list[2]
 
           base_img[loc_ymin:ymax,loc_xmin:xmax] = tmp
           save_img_name = base_img_name.split('.')[0]+name.split('.')[0]+"_"+str(count_k)+".jpg"	
           save_f = open(list_file + "box_"+shot+"_"+novel_label_list+"_train.txt","a")             
           save_f.write('datasets/VOC2007/JPEGImages/'+save_img_name+'\n')
           cv2.imwrite(save_img_root+save_img_name,base_img) 
           labels_base,diffs_base,bboxs_base=reader.load(base_xml_path)
           save_xml(W,H,labels_base,diffs_base,bboxs_base,save_img_name,save_root, novel_label_list, novel_bbox_list) 
           base_img = None
 
