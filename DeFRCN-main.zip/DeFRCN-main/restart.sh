rm -rf datasets/VOC2007/*_1/* &&
rm -rf datasets/VOC2012/*_1/* &&
#rm -rf datasets/vocsplit/seed0-cp &&
rm -rf datasets/vocsplit/seed0 &&
cp -r datasets/vocsplit/seed0-origin datasets/vocsplit/seed0 #&&
#rm -rf data/few_shot_ann/voc/benchmark_1shot 
