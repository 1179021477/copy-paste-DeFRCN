'for num in 1 2 5 10 20 50 100 200 500 700 1000
do
shot=1
echo $num
sh restart.sh &&
python read_xml_real_novel_on_base.py -s $shot -n $num &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
sh run_voc-exp-1shot.sh baseline 1
echo "1a"
done'

for num in 1 2 5 10 20 50 100 200 500 700 1000
do
shot=3 &&
sh restart.sh &&
python read_xml_real_novel_on_base.py -s $shot -n $num &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
sh run_voc-exp-3shot.sh baseline 1 &&
echo "3a"
done

for num in 1 2 5 10 20 50 100 200 500 700 1000
do
shot=5 &&
#file="a" &&
sh restart.sh &&
python read_xml_real_novel_on_base.py -s $shot -n $num &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
sh run_voc-exp-5shot.sh baseline 1
echo "5a"
done


for num in 1 2 5 10 20 50 100 200 500 700 1000
do
shot=10 &&
#file="a" &&
sh restart.sh &&
python read_xml_real_novel_on_base.py -s $shot -n $num &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
sh run_voc-exp-10shot.sh baseline 1 &&
echo "10a"
done



'for num in 10 20 50 100 200
do
shot=3 &&
file="a" &&
sh restart.sh &&
python read_xml_gennovel_on_rand_base.py -s $shot -n $num -f $file &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
sh run_voc-exp-3shot.sh baseline 1
echo "3a"
done
'
