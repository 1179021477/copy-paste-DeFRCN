#for num in 20 #10 20 50 100 200
#do

num=20
file="a"
echo $num
#sh restart.sh &&
#python read_xml_gennovel_instance_on_rand_base.py -s $shot -n $num -f $file &&
#python get_new_base_novel_list_gen.py -s $shot &&
#sh after_xml.sh &&

for shot in "3" "5" "10" 
do
for score in "0.1" "0.2" "0.3" "0.5" #"0.8"
do
echo $shot
echo $score
sh restart.sh &&
python read_xml_gennovel_instance_on_rand_base.py -s $shot -n $num -f $file &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
cp -r defrcn/evaluation/pascal_voc_evaluation_${score}.py defrcn/evaluation/pascal_voc_evaluation.py &&
python self_train_add_novel.py -sh $shot -sc "0.8" -scm "0.5" && #revise clip_path and model score
python self_train_add_novel_after.py -s $shot &&
sh after_xml_self_train.sh &&
sh run_voc-exp-${shot}shot.sh baseline 1
#mv test_res_clip.txt test_res_clip_trainval2007_${score}_${shot}shot.txt
done
done




'
0 50 100 200
do
shot=3 &&
file="a" &&
sh restart.sh &&
python read_xml_gennovel_on_rand_base.py -s $shot -n $num -f $file &&
python get_new_base_novel_list_gen.py -s $shot &&
sh after_xml.sh &&
sh run_voc-exp-3shot.sh baseline 1
echo "3a"
done
'
