import os
import json
import shutil
import cv2
f = open("./test_res/test_res_split1_1shot.txt","r")
#f = open("test_res.txt")
#base_list = "datasets/VOC2007/ImageSets/Main/test_VOC2007.txt"
#f_base = open(base_list,"r")
f_save = open("base_list/select_base-split1-1shot-0.6-3-withlabel-thresh.txt","a")

base = []
#base_lines = f_base.readlines()

img_path = "datasets/VOC2007/JPEGImages/"
new_path = "select_imgs"
if not os.path.exists(new_path):
    os.makedirs(new_path)

lines = f.readlines()
k = 0
select_base = []
count = 0
label = [15,16,17,18,19]
thresh = 0.5
thresh_low = 0.5

nums_list = {"15":0,"16":0,"17":0,"18":0,"19":0}
num_thresh = 3-1

wrong_label_list = []
#full_list = []
#for line in base_lines:
#    full_list.append(line)
#print(len(full_list))
for line in lines:
    k += 1
    info = json.loads(line)
    if k ==1:
        print(len(info))#4952 20
        res_list = info
        for i in range(5):
            i = str(i)
            for n in range(len(res_list[i])):
               #flag = False
               #print(len(res_list[i][n])) #6
               if len(res_list[i][n]) > 0:
                       #print(res_list[i][n][1])
                       if float(res_list[i][n][1]) > thresh and float(res_list[i][n][1]) < 0.9: # and res_list[i][n][m][4] > thresh_low:
                           #print(n)
                           ## same number for each class
                           if nums_list[str(int(i)+15)] > num_thresh: 
                               continue
                          
                           print(nums_list)

                           nums_list[str(int(i)+15)] += 1
                           count+=1
                           #flag = True
                           wrong_label_list.append(int(i)+15)
                           [name,cf,x1,y1,x2,y2] = res_list[i][n]
                           select_base.append(name)
                           img_name = name+".jpg"
                           img = cv2.imread(img_path+"/"+img_name)
                           [name,cf,x1,y1,x2,y2] = res_list[i][n]
                           print(name,cf,x1,y1,x2,y2)
                           x1 = float(x1)
                           y1 = float(y1)
                           x2 = float(x2)
                           y2 = float(y2)
                           cv2.rectangle(img,(int(x1),int(y1)),(int(x2),int(y2)),(255,0,0),2)
                           cv2.putText(img, str(int(i)+15), (int(x1), int(y1)), cv2.FONT_HERSHEY_COMPLEX, 0.8, (0, 255, 0), 2)
                           cv2.imwrite(new_path+"/"+img_name,img)
                         
                           #break
    else:
        anno = eval(info["final_anno"])
        print(len(anno))
        print(anno[0])
print("num:",len(select_base),len(wrong_label_list))
print(nums_list)
prefix = "datasets/VOC2007/JPEGImages/"
count = 0
for k in select_base:
    img_name = k+".jpg"
    f_save.write(prefix+img_name+" "+str(wrong_label_list[count])+"\n")
    count += 1
    #shutil.copy(img_path+img_name, new_path+"/"+img_name)
