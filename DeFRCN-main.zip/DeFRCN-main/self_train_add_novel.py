#coding : utf-8
import os
import cv2
import abc
import xml.dom.minidom as xml
import math
import matplotlib.pyplot as plt
from PIL import Image

from add_xml import save_xml 
import random
import numpy as np
import torch
import torchvision.transforms.functional as TF
import torchvision.transforms as transforms
import copy
import json


 
 
if __name__ == "__main__":


    class_name1 = ['bird', 'bus', 'cow', 'motorbike', 'sofa'] #1
    class_name2 = ['aeroplane', 'bottle', 'cow', 'horse', 'sofa'] #2
    class_name3 = ['boat', 'cat', 'motorbike','sheep','sofa']

    import argparse
    parser = argparse.ArgumentParser(description='subcommand for getting frames')
    parser.add_argument('-sh', help='shot') #1 to 10
    parser.add_argument('-sc',help='score') #clip score
    parser.add_argument('-scm',help='model score') 
    parser.add_argument('-sp',help='split')
    args = parser.parse_args()
    print(args)
    shot = args.sh +"shot"
    score = args.sc
    model_score = float(args.scm)
    sp = args.sp
    if int(sp) == 1:
        class_name = class_name1
    if int(sp) == 2:
        class_name = class_name2
    if int(sp) == 3:
        class_name = class_name3

    data_root = "datasets/" #"data/VOCdevkit/" 
    data_path = data_root + "VOC2007/JPEGImages/"
    save_root = data_root + "VOC2007/Annotations_1/"
    save_img_root = data_root + "VOC2007/JPEGImages_1/"

    #os.system("rm -rf "+save_root+"*")
    #os.system("rm -rf "+save_img_root+"*")
    #shot = '1shot'
    #list_file = "/nvme/nvme2/linshaobo/text_to_img_generator/sd_save_VOC_split1_imagenetprompts_a_200_newrect_cutout_remove/"  

    res_clip = "/nvme/nvme2/linshaobo/DeFRCN-main/test_res_clip_trainval2007_"+score+"_"+shot+"_split"+str(sp)+".txt" #_nogen_clip0.8.txt"
    S = model_score

    f_clip = open(res_clip,"r")
    lines = f_clip.readlines()
    info = json.loads(lines[0])
    print("len:",len(info))
    res_json = {}
    for k in range(len(info)):
        class_info = info[str(k)]
        for i in range(len(class_info)):
              print(class_info[i])
              name,score,x1,y1,x2,y2 = class_info[i].split(" ")
              #print(name,score)
              img = cv2.imread(data_path+name+".jpg")
              H,W,C = img.shape 
              #print(H,W)         
              xml_path = data_root + "VOC2007/Annotations/"+name+".xml"
              save_img_name = class_name[k]+"_"+name+".jpg"
              if float(score) > S:
                  cv2.imwrite(save_img_root+save_img_name,img)                     
              
              score = float(score)
              x1 = int(float(x1))
              y1 = int(float(y1))
              x2 = int(float(x2))
              y2 = int(float(y2))

              if name in res_json:
                    res_json[name].append([k,score,[x1,y1,x2,y2],W,H])
              else:
                   res_json[name] = []
                   res_json[name].append([k,score,[x1,y1,x2,y2],W,H])
print(res_json)
print("len json:",len(res_json))

for i in res_json:
     novel_label_list, novel_bbox_list =[],[]
     for j in range(len(res_json[i])):
         score = res_json[i][j][1]
         box = res_json[i][j][2]
         W,H = res_json[i][j][3],res_json[i][j][4]
         if score > S:
             novel_label_list.append(class_name[res_json[i][j][0]])
             novel_bbox_list.append(box)
             labels_base,diffs_base,bboxs_base = [],[],[]
             save_img_name = class_name[res_json[i][j][0]]+"_"+i+".jpg"
             
             save_xml(W,H,labels_base,diffs_base,bboxs_base,save_img_name,save_root, novel_label_list, novel_bbox_list) 
 
